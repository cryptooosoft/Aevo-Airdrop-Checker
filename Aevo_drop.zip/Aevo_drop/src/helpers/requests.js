require('./functions.js')()

const axios = require('axios')
const { HttpsProxyAgent } = require('https-proxy-agent')

async function doRequest(config) {
	let retry = 0
	let start = Date.now()
	while (retry < config.retries) {
		try {
			let requestConfig = {
				method: config.method,
				url: config.url,
				data: config.data,
				headers: config.headers,
				params: config.params,
				timeout: config.timeout,
				httpsAgent: new HttpsProxyAgent(`http://${getRandomProxy()}`),
			}

			const response = await axios(requestConfig)

			let timeTaken = Number(((Date.now() - start) / 1000).toFixed(2))

			if (response['status'] != 200) return { status: Boolean(false), msg: Number(response['status']) }

			return {
				status: Boolean(true),
				data: Object(response['data']),
				resTime: timeTaken,
			}
		} catch (e) {
			await delay(config['request_retry_delay_ms'])
			++retry
			if (retry == config.retries) return { status: Boolean(false), msg: String(e?.message) }
		}
	}
}

module.exports = { doRequest }
